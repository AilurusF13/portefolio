#include "affichage.h"

void displayScreen(Map m, String (* lecteur)(String)){

    CoupleInt c = m->dim;

    for(c.y = 0; c.y < m->dim.y ;c.y++){   
        for(c.x = 0; c.x < m->dim.x ; c.x++){
            
            displayTexture(c, displayConverter(plan_getObjet(m->plan, m->dim ,c), lecteur));
        }
    }
}


String displayConverter(Objet o, String (* lecteur)(String)){
    switch (o)
    {
    case 0:
        return lecteur("vide.texture");
        
    case 1:
        return lecteur("bloc.texture");
        
    case 2:
        return lecteur("cible.texture");
        
    case 3:
        return lecteur("mur.texture");
        
    case 7:
        return lecteur("perso.texture");
        
    default:
        return lecteur("error.texture");
    }
} 

void displayTexture(CoupleInt dim, String string){
    dim.y *= MAX_LIGNE;
    dim.x *= MAX_CHARACTER ;
    int o_x = dim.x;

    for(int i = 0; string[i] !='\0';i++){
        if(string[i]=='\n'){
            dim.y++;
            dim.x = o_x;
        }
        else{
            mvprintw((dim.y),(dim.x++),"%c",string[i]);
            // mvaddstr(HAUTEUR*dim.y, LARGEUR*(dim.x++), "t");
        }
    }
    free(string) ;
}