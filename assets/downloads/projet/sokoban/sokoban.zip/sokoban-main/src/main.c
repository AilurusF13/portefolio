#include "utils.h"
#include "menu.h"

int main() {
    Map m ;
    Plan p ;
    CoupleInt dim ;
    Nat nb_cible ;
    Nat num_level ;
    FILE* fichier ;

    char continuer;

    do {
        num_level = menu_choixNiveau() ;

        char nom_fichier[30] ;
        char chemin_fichier[50] ;
        sprintf(nom_fichier, "%u.level", num_level) ;
        sprintf(chemin_fichier, "levels/%s", nom_fichier);

        printf("Level sélectionné : %s\n", nom_fichier) ;
        fichier = fopen(chemin_fichier, "r");

        if (fichier == NULL) {
            printf("Erreur : Fichier non-trouvé\n");
            return 5;
        }
        fclose(fichier) ;

        // Init des éléments.
        p = lecture_extractLevel(nom_fichier, &dim, &nb_cible) ;
        m = map_init(dim, p, nb_cible) ;

        if (!menu_testTexture()) {
            printf("Erreur : fichiers texture manquants\n") ;
            return 1 ;
        }  

        if (!pre_PlanNonNull(m->plan, m->dim)) {
            printf("Échec de l'initialisation du niveau\n") ;
            return 2 ;
        }

        if (!pre_dimension(m->dim)) {
            printf("Erreur : dimension du niveau invalide\n") ;
            return 3 ;
        }

        if (!pre_cible(m)) {
            printf("Erreur : nombre de cibles et caisses invalide\n") ;
            return 4 ;
        }

        menu_jeu(m) ;

        map_free(m) ;

        // Demander la confirmation pour continuer
        printf("Voulez-vous continuer? (Appuyez sur 'c' pour continuer, 'q' pour quitter)\n");
        scanf(" %c", &continuer);
    } while (continuer == 'c' /*|| continuer == 'C'*/);

    return 0;
}
