#include "lecture.h"

Plan lecture_extractLevel(String nom_fichier,CoupleInt* dim, Nat* nbCible){

    char cheminComplet[100] = CHEMIN_LEVEL;

    strcat(cheminComplet, nom_fichier);

    FILE *fichier = fopen(cheminComplet , "r");

    fscanf(fichier, "%d %d %d", &(dim->x), &(dim->y), nbCible);

    Nat compteurCible = 0;
    int x;
    int y;

    Plan p = plan_init(*dim);

    //rempli la map des valeurs
    for(y=0; y<dim->y; y++){
        for(x=0; x<dim->x; x++){
            #pragma GCC diagnostic ignored "-Wformat"
            fscanf(fichier, "%d", &(p[y][x]));
            if (p[y][x] == 2){
                compteurCible++;
            }
        }
    }

    return p;
}


String lecture_extractTexture(String nom_fichier){
    char cheminComplet[100] = CHEMIN_TEXTURE;

    strcat(cheminComplet, nom_fichier);

    FILE *fichier = fopen(cheminComplet , "r");

    String pointeur = MALLOCN(char, (MAX_LIGNE * MAX_CHARACTER)+1);

    fread(pointeur, sizeof(char), (MAX_LIGNE * MAX_CHARACTER)+2, fichier);
    pointeur[ftell(fichier)] = '\0';

    fclose(fichier);

    return pointeur;
}


Bool pre_cible(Map m){

    Nat nbCible = m->cibleTOT ; 

    // nbrCible conforme (>= 1)
    if(nbCible < 1){
        return false;
    }

    int compteurCible = 0;
    int compteurBoite = 0;

    int y;
    int x;
    int valeur;
    for(y=0; y<m->dim.y; y++){
        for(x=0; x<m->dim.x; x++){
            valeur = m->ref[y][x] ;
            if (valeur == 2){
                compteurCible++;
            } else if(valeur == 1){
                compteurBoite++;
            }
        }
    }
    if(nbCible != compteurCible || compteurBoite != compteurCible){
        return false;
    }
    return true;

}

Bool pre_PlanNonNull(Plan p, CoupleInt dim){
    if (p == NULL){
        return false;
    }

    Bool finBoucle = true;

    for (int y = 0; y<dim.y; y++){
        if (p[y] == NULL){
            finBoucle = false;
        }
    }

    return finBoucle;
}

Bool pre_dimension( CoupleInt dim) {
    return (dim.x > 2 && dim.y > 4) || (dim.y > 2 && dim.x > 4) ;
}
