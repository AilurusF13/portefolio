#include "map.h"

//##################### FONCTIONS PRIVEES DECLARATIONS ############################################################################

/*! \brief copie le plan donnée avce ses dimensions
    \return pointeur (plan) du plan copié.
*/
Plan copy(Plan p, CoupleInt dim);

/*! \brief Retourne la premiere apparence de l'objet trouvé dans la matrice
    \pre l'objet o est présent dans le plan p
    \return Coordonées de l'objet trouvé
*/
Coord search(Plan p, CoupleInt dim, Objet o);

/*! \brief Déplace le personnage avec une caisse dans le.
    \pre nouv et suivant sont compris dans la matrice.
    \param m Map sur laquelle l'opération a lieu.
    \param nouv Nouvelle coordonnée du personnage.
    \param suivant Coordonnée positionnée apres la nouvelle en fonction de la position du personnage.
    
    \note La fonction prend en compte les caisses qui couvrent ou découvre des cibles.
    \note Le nombre de mouvement est incrémenté.
*/
Map mvtCaisse(Map m, Coord nouv,Coord suivant);

/*! \brief Déplace le personnage.
    \pre nouv est compris dans la matrice.
    \param m Map sur laquelle l'opération a lieu.
    \param nouv Nouvelle coordonées du personnage.
    \note Le nombre de mouvement est incrémenté.
*/
Map mvtSimple(Map m, Coord nouv);

/*! \brief Deplace un objet d'une coordonnée à une autre.
    \pre a et b sont compris dans la matrice de reference de la map.
    \param m Map sur laquelle l'opération a lieu.
    \param a Coordonnées de l'objet qui sera déplacé.
    \param b Coordonnées où l'objet sera déplacé.
    \note la coordonnée a est remise a son etat d'origine. 
*/
Map deplacement(Map m, Coord a, Coord b);

//##################### FONCTIONS PUBLIQUES DEFINITIONS ############################################################################

Map map_init(CoupleInt dimension, Plan reference, Nat nb_cible) {
    Map m = MALLOC(strMap);
    m->dim = dimension;
    m->ref = reference;
    m->plan = copy(reference, dimension);
    m->perso = search(reference, m->dim , PERSO);
    m->mvt = 0;
    m->cibleTOT = nb_cible;
    m->manquant = nb_cible;
    return m;
}

Map map_reset(Map m) {
    plan_free(m->plan, m->dim) ;
    m->plan = copy(m->ref, m->dim);
    m->perso = search(m->ref, m->dim , PERSO);
    m->mvt = 0;
    m->manquant = m->cibleTOT;
    return m;
}

Bool map_preMvt(Map m, CoupleInt ajoute) {
    Coord nouv_coord = coupleInt_add( m->perso , ajoute );
    Bool mvt_fait ;

    Bool mvt_de_un = abs(ajoute.x) + abs(ajoute.y) == 1;
    Bool est_mur = plan_getObjet(m->plan,m->dim, nouv_coord ) == MUR;
    Bool est_caisse = plan_getObjet(m->plan, m->dim, nouv_coord ) == CAISSE ;
    Coord __attribute__((__unused__)) derriere;
    Bool __attribute__((__unused__)) derriere_est_plein ;
    if (est_caisse) { // On est sûr que le bloc derriere est dans la matrice
        Coord derriere = coupleInt_add(nouv_coord, ajoute) ;
        derriere_est_plein = plan_getObjet(m->plan,m->dim, derriere) & 0x1; // si dernier bit est 1 retourne true
    }

    /*
        Si le mouvement n'est pas de 1 ou que l'on veut se deplacer sur un bloc, on ne se déplace pas
        Sinon on veut se deplacer sur une caisse, 
            si celle de derrière est une caisse ou un mur on ne se deplace pas sinon on se deplace et decalle la caisse fsi
        Sinon on se deplace sur la zone qui est libre (vide ou cible) fsi
    */
    if ( nouv_coord.y > m->dim.y-1 || nouv_coord.x > m->dim.x-1 /* On se déplace bien dans le quadrillage */|| !mvt_de_un || est_mur ){
        mvt_fait = faux;
    } else if ( est_caisse ) {
        if ( derriere_est_plein ) {
            mvt_fait = faux;  // ne sera pas *initialisée* et pas evalué plus haut si est_caisse est faux
        } else {
            m = mvtCaisse( m, nouv_coord, derriere );
            mvt_fait = true;
        }
    }else {
        m = mvtSimple(m, nouv_coord);
        mvt_fait = true;
    }
    return mvt_fait;
}

Bool map_victoire(Map m) {
    return m->manquant == 0;
}

Plan plan_init(CoupleInt dim) {
    Plan p;
    p = MALLOCN( Objet* , dim.y );
    for (int i = 0 ; i < dim.y ; i ++){
        p[i] = MALLOCN(Objet, dim.x);
    }
    return p;
}

CoupleInt map_getDim(Map m) {
    return m->dim;
}

Plan map_getPlan(Map m) {
    return m->plan;
}

Nat map_getMvt(Map m) {
    return m->mvt;
}

Nat map_getManquant(Map m) {
    return m->manquant;
}

Objet plan_getObjet(Plan p, CoupleInt dim, Coord coord) {
    return p[coord.y][coord.x] ;
}

Bool pre_getObjet(Plan p, CoupleInt dim, Coord coord) {
    return dim.x > coord.x && dim.y > coord.y;  
}

CoupleInt coupleInt_add(CoupleInt a, CoupleInt b) {
    a.x += b.x ;
    a.y += b.y;
    return a;
}

void plan_free(Plan p, CoupleInt dim) {
    for(int i = 0 ; i < dim.y ; i ++)
        FREE(p[i]) ;
    FREE(p) ;
}

void map_free(Map m) {
    // free les deux plan puis strucure
    plan_free(m->ref, m->dim) ;
    plan_free(m->plan, m->dim) ;
    FREE(m) ;
}

//##################### FONCTIONS PRIVEES DEFINITIONS ############################################################################

Plan copy(Plan p, CoupleInt dim) {
    Plan p2 = plan_init(dim);
    for (int y = 0 ; y < dim.y ; y++)
        for (int x = 0 ; x < dim.x ; x++)
            p2[y][x] = p[y][x] ; 
    return p2;
}

Coord search(Plan p, CoupleInt dim , Objet o) {
    Coord c;
    for (int y = 0 ; y < dim.y; y++)
        for (int x = 0 ; x < dim.x ; x++)
            if (p[y][x] == o){
                c.x = x;
                c.y = y;
            };
    return c;
}

Map mvtCaisse(Map m, Coord nouv,Coord suivant) {
    deplacement(m, nouv, suivant);
    deplacement(m, m->perso, nouv);
    m->perso = nouv;
    m->mvt ++;
    // si la caisse etait une cible, il y aura plus de non-couverte
    if ( plan_getObjet(m->ref,m->dim, nouv) == CIBLE ) m->manquant ++;
    // si la caisse est poussée sur une cible, il y aura moins de non-converte
    if ( plan_getObjet(m->ref, m->dim ,suivant) == CIBLE ) m->manquant --;
    return m;
}

Map mvtSimple(Map m, Coord nouv) {
    deplacement(m, m->perso, nouv );
    m->perso = nouv;
    m->mvt ++;
    return m;
}

Map deplacement(Map m, Coord a, Coord b){
    m->plan[b.y][b.x] = plan_getObjet(m->plan,m->dim, a);
    m->plan[a.y][a.x] = (plan_getObjet(m->ref,m->dim, a) & 0x1) ? VIDE : plan_getObjet(m->ref,m->dim, a);
    return m;
}
