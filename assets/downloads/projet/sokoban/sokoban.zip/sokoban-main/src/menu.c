#include "menu.h"

/*############################ - DECLARATION PRIVE - #######################*/

void game_loop(Map m) ;

/*############################ - DEFINITION PUBLIC - #######################*/

Nat menu_choixNiveau() {
    Nat niveau;
    int tentatives_max = 20; // Nombre maximal de tentatives

    for (int tentative = 1; tentative <= tentatives_max; ++tentative) {
        printf("Choisissez votre niveau parmis les %d (tentative %d/%d) : ", NB_LEVEL , tentative, tentatives_max);
        if (scanf("%u", &niveau) == 1 && niveau > 0 && niveau <= NB_LEVEL) {
            // Entrée valide, sortir de la boucle
            break;
        } else {
            // Entrée invalide, afficher un message d'erreur
            printf("Erreur : Veuillez entrer un niveau valide.\n");

            // Nettoyer le tampon d'entrée (flush)
            while (getchar() != '\n');

            // Si c'est la dernière tentative, afficher un message et quitter
            if (tentative == tentatives_max) {
                printf("Nombre maximal de tentatives atteint. Quitter le programme.\n");
                exit(EXIT_FAILURE);
            }
        }
    }
    return niveau ;
}

// test présence
Bool menu_testTexture() {
    String textures[TEX_NUM] = TEXTURES ;
    char path[100] ;
    FILE* f ;
    for (int i = 0 ; i < TEX_NUM/*nombre de texture*/ ; i++ ) {
        sprintf(path, "textures/%s.texture", textures[i]) ;
        f = fopen( path , "r")  ;
        if ( f == NULL) {
            return faux;
        }
    }
    return vrai ;
}

// tester si bien écrit
Bool menu_testMap(Map m) {
    return pre_PlanNonNull(m->plan, m->dim) && pre_dimension(m->dim) ;
}

// boucle
void menu_jeu(Map m) {

    initscr() ;

    game_loop(m) ;
    

    clear() ;
    endwin();
    // Message de fin du jeu ?
}

/*############################ - DEFINITION PRIVE - #######################*/

void game_loop(Map m) {
    Nat info_y = (m->dim.y * MAX_LIGNE) + 2;
    Nat info_x = (m->dim.x * MAX_CHARACTER) / 2;
    noecho() ;
    curs_set(0) ;
    displayScreen(m, lecture_extractTexture);
    refresh();
    while (!map_victoire(m)){
        char charMouvement = getch();
        switch (charMouvement) {
            case HAUT:
                map_preMvt(m, (CoupleInt){0, -1});
                break;
            case BAS:
                map_preMvt(m, (CoupleInt){0, 1});
                break;
            case GAUCHE:
                map_preMvt(m, (CoupleInt){-1, 0});
                break;
            case DROITE:
                map_preMvt(m, (CoupleInt){1, 0});
                break;
            case QUIT:
                return ;
            case RESET :
                map_reset(m) ;
                break ;
            default:
                break;
        }
        mvprintw(info_y,info_x,"Nombre de mouvements : %d",map_getMvt(m));
        mvprintw(info_y+2,info_x,"Se déplacer : %c%c%c%c",HAUT,GAUCHE,BAS,DROITE);
        mvprintw(info_y+3,info_x,"Recommencer : %c",RESET);
        mvprintw(info_y+4,info_x,"Quitter     : %c",QUIT);
        displayScreen(m, lecture_extractTexture);
        refresh() ;
    }
    mvprintw(info_y+6,info_x,"Partie Términée :) Merci d'avoir joué. \t-Kian");
    refresh() ;
    sleep(FIN_SLEEP) ;
}