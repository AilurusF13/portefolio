

#ifndef MENU
#define MENU

#include <stdio.h>
#include <ncurses.h>
#include <unistd.h>
#include "utils.h"
#include "map.h"
#include "affichage.h"
#include "lecture.h"

#define GAUCHE 'q'
#define DROITE 'd'
#define HAUT 'z'
#define BAS 's'

#define RESET 'r'
#define QUIT 'e'

#define TEXTURES {"bloc", "cible", "error", "mur", "perso", "vide"}
#define TEX_NUM 6

#define NB_LEVEL 10 //!< Nombre de niveau max

#define MAX_PARTIE 20

#define FIN_SLEEP 2

/*! \brief Permet a l'utilisateur de choisir son niveau par entrée systeme
    \return Naturel représentant le niveau choisis
    La fonction fait attention à choisir demander et entrer un entier valide, si l'entrée n'est pas valide il demande à nouveau
    (idée) La fonction peut-être récursive mais si c'est cas possède un nombnre d'appel limité
*/
Nat menu_choixNiveau() ;

/*! \brief Test si toutes les textures nécéssaires sont présentes dans le system de fichier/
    \return true si elles sont présentes, false sinon.
*/
Bool menu_testTexture() ;

/*! \brief Test si numéro donnée est bien un fichier existant
    \param num_level numéro du niveau sur lequel le test de présence est fait
    \return true si présent, false sinon
    convertit le numéro en nom de fichier dans la fonction pour la reherche
*/
Bool menu_testLevel(Nat num_level) ;

// boucle
void menu_jeu(Map m) ;

 #endif