/*! \file map.h
    \brief Strucure de mise en mémoire des informations

    structure contenant informations des niveaux et méthodes associées
*/
#ifndef MAP
#define MAP

#include <stdlib.h>
#include "utils.h"


//! \brief Objets composants les matrice de plan
typedef unsigned int Objet;
/*! \brief Matrice contenant tous les objets du niveau.
    Exemple de matrice 3x3 :
    {
        {0, 1, 2},
        {4, 5, 6},
        {7, 8, 9}
    }
    La valeur 0 est l'origine
    (0, 0) = 0
    (1, 1) = 5
    (2, 0) = 7
*/
typedef Objet** Plan;

#define VIDE 0 // 000
#define CAISSE 1 // 001
#define CIBLE 2 // 010
#define MUR 3 // 011
// pair -> vide
#define PERSO 7

/*! \brief Structure principale du projet contenant les informations d'un niveau.
*/
typedef struct strMap {
    CoupleInt dim;
    Plan ref; //!< plan de référence
    Plan plan; //!< plan où auront lieu les modifications
    Coord perso; //!< coordonées du personnage se déplaçant
    Nat mvt; //!< nombre de mouvements fait depuis le debut de la partie
    Nat cibleTOT; //!< nombre totale de cible où poser des caisses pour gagner
    Nat manquant; //!< nombre de caisse manquante avant victoire
} strMap, *Map;

//##################### FONCTIONS PUBLIQUES DECLARATIONS ############################################################################

/*! \brief Initalisation de la structure
    \pre Plan non null
    \pre dimension(x, y) = (x>3 et y>5) ou (x>5 et y>3) 
    \pre reference avec i, j coordonnées = (i, 0) = MUR et (0, j) = MUR => toutes les bordures sont  des murs
    \pre nb_cible = nb_cible > 0
    \pre nb_cible = nombre de CIBLE dans le niveau
    \return Pointeur Caché Map ou StrMap*
    \param dimension Dimensions du Plan (matrice d'Objet) dans un couple (x, y).
    \param reference Matrice represantant chaque objet du niveau avec le type Objet, rien de spécial. 
    \param nb_cible Nombre de cible présente dans le niveau, les places sur lequels le joeur doit poser des caisses. 
*/
Map map_init(CoupleInt dimension, Plan reference, Nat nb_cible);

/*! \brief Réinitialise la structure Map.
    \return Pointeur Caché Map ou StrMap*
    \param m Map à reinitialiser.
    Permet la réinitialisation des elements- de map pour recommencer une partie a partir du même niveau/de la même référence.
*/
Map map_reset(Map m);

/*! \brief Permet au personnage d'effectuer un mouvemement à une coodonnées donnée.
    \return Un booléen représentant le succès de l'opération de déplacement : Réussi : vrai sinon faux.
    \param m Map ou aura lieu l'opération.
    \param ajoute Couple représentant le mouvement du personnage (doite, gauche, haut, bas) en fonction du x et y.

    La fonction effectue le mouvement si et seulement si :
        - la nouvelle cordonnée donnée ne représente pas un mur.
        - le deplacement est d'une unité en x ou y mais pas les deux.
        - si la nouvelle coordonée représente une caisse, qu'il n'y ai pas de caisse ou de mur apres celui-ci.
*/
Bool map_preMvt(Map m, CoupleInt ajoute);

/*! \brief Determine si la partie est terminée ou non.
    \return Vrai si la partie est terminée/gagnée et faux sinon.
    \param m structure où la partie a lieu.
*/
Bool map_victoire(Map m);

/*! \brief initalise un plan dans le heap
    \param dim Couple portant les dimensions de la matrice qui doit-être créer 
*/
Plan plan_init(CoupleInt dim);

/*! \brief getter sur les dimensions du plan de la map donnée.
    \return un couple x, y représentant les dimensions du plan.
    \param m Structure où seront extraites les dimensions.
*/
CoupleInt map_getDim(Map m);

/*! \brief getter sur le plan de la map donnée.
    \return Le Plan (matrice d'Objet) de la structure donnée.
    \param m Structure où sera extraite le plan.
*/
Plan map_getPlan(Map m);

/*! \brief getter sur nombre de mouvement de la map donnée.
    \return Nombre de mouvemment effectuées depuis le debut de cette partie(manche).
    \param m Structure d'où sera extrait le nombre de mouvement.
*/
Nat map_getMvt(Map m);

/*! \brief getter sur le nombre de cible du plan encore présente.   
    \brief Nombre de cible sur le plan qui n'ont pas étés compàlétés par une caisse.
    \param m Structure ou sera extrait le nombre de cible manquante.
*/
Nat map_getManquant(Map m);

/*! \brief getter sur un element du plan donné.
    \pre les dimensions du plan p sont superieurs ou égals aux coordonnées données.
    \return Objet résidant aux coordonées donnés du plan.
    \param p Plan sur lequel l'objet sera récupérer.
*/
Objet plan_getObjet(Plan p, CoupleInt dim, Coord coord) ;

Bool pre_getObjet(Plan p, CoupleInt dim, Coord coord);

/*! \brief Ajoute les deux entiers d'un couple ou les deux coordonnés d'un couple de coordonnés
    \return un troisieme couple ou coordonnés resultant de l'addition.
    \param a, b Les Opérandes de l'addition, CoupleInt ou Coord.
*/
CoupleInt coupleInt_add(CoupleInt a, CoupleInt b);

/*! \brief Permet des libérer l'espace allouée à la matrice
    \param p matrice plan à libérer
*/
void plan_free(Plan p, CoupleInt dim) ;

/*! \brief Permet des libérer l'espace allouée à la structure
    \param m structure Map à libérer
    On liberera bien sur les element que l'on arrete d'utiliser à l'interieur.
*/
void map_free(Map m) ;

#endif