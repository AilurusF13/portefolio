/*! \file utils.h   
 *  \brief Fichier d'outillage
 * 
 *  Ce fichier headers contient différentes macros et constantes du projet.
 */
#ifndef UTILS
#define UTILS

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define MAX_LIGNE 3
#define MAX_CHARACTER 5

#define MAX_LIGNE_LEVEL 20
#define MAX_CHARACTER_LEVEL 20

#define HELLO printf("Hello, World !\n"); /*!< Cette ligne de code sert d'exemple et de teste*/

//! \brief Entiers Naturel.
typedef unsigned int Nat;

//! \brief Chaine de character
typedef char* String;

//! Variant du type boolean avec du français.
typedef int Bool;
#define vrai 1;
#define faux 0;

#define MALLOC(type)        ((type*)malloc(sizeof(type)))
#define CALLOCN(type, n)    ((type*)calloc( n, sizeof(type)))
#define MALLOCN(type, n)    ((type*)malloc( (n) * sizeof(type)))
#define REALLOC(t, type, n) ((type*)realloc(t, (n) * sizeof(type)))
#define FREE(t) free(t)

/*! \brief Structure permettant de représenter un couple d'entier. Par défaut 
    \param x, y Entiers signés.
*/
typedef struct {
    int x;
    int y;
} CoupleInt, Coord ;

#endif