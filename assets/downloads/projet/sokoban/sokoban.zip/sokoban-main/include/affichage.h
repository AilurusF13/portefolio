/*! \file affichage.h
 *  \brief Fichier contenant les fonctions d'affichages du jeu
 *    
 *  Ce fichier headers contient les différentes fonctions qui seront utilisées pour afficher la carte du jeu, le joueur, les obstacles, etc... 
 *
 */

#ifndef AFFICHAGE
#define AFFICHAGE

#include <ncurses.h>
#include <stdlib.h>
#include "utils.h"
#include "map.h"

/*! \brief Affichage à l'écran du plan de la structure map
 *  \return vide
 *  \param m Structure d'où le plan sera utilisé pour l'affichage.   
 */
void displayScreen(Map m, String (* lecteur)(String));

/*! \brief Fonction de conversion pour obtenir la texture.
 *  \return Retourne la conversion en char* de l'objet.
 *  \param o Variable de type Objet.   
 */
String displayConverter(Objet o, String (* lecteur)(String));

/*! \brief Fonction qui affiche la texture du plan.
 *  \return vide
 *  \param dim type CoupleInt et string type char* qui est une texture.    
 */
void displayTexture(CoupleInt dim, String
 string);

#endif

