#ifndef LECTURE
#define LECTURE

#include "utils.h"
#include "map.h"
#include <string.h>
#include <stdlib.h>

#define CHEMIN_TEXTURE "textures/"
#define CHEMIN_LEVEL "levels/"

//######################## FONTCTIONS MERES ############################################################################################################

Plan lecture_extractLevel(String nom_fichier,CoupleInt* dim, Nat* nbCible) ;

String lecture_extractTexture(String nom_fichier);

//######################## FONCTIONS DE PRECONDITIONS ############################################################################################################

/*! \brief Verifie que le plan ne soit pas nul.
*/
Bool pre_PlanNonNull(Plan p, CoupleInt dim);

/*! \brief Vérifie le respect des dimensions minimales d'un plan
*/
Bool pre_dimension(CoupleInt dim);

/*! \brief Vérifie le nombre de cibles minimale d'un plan, 
si le nombre de cible indiqué est égal au nombre de cibles réel et 
si le nombre de boites est égal au nombre de cible
*/
Bool pre_cible(Map m);

#endif