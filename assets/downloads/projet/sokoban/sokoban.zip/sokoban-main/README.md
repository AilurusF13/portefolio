# README SOKOBAN

Lisez vraiment svp, ce sont des infos importantes les gars

## Prérequis

- préférence pour le compilateur gcc
- librairie ncurses
- make

## Archive

Excetutez `make archive` afin de générer une archive du projet dans le *./bin*.

## Fichier Makefile

### compilation

`make` peut-etre utilisé fin de créer l'executable
Par défaut, `make run` pour lancer la compilation puis execution du projet en une commande

### dépendances des executables

Afin de gerer les dépendances d'un executable -qui sera par défaut dans le *./bin* :

```Makefile
./bin/cible : $(OBJ)/dependance1.o $(OBJ)/dependance2.o
    $(CC) $^ -o $@ $(CFLAGS)
#noter les dépendances de tous les fichiers.o utilisés (noter les dépendances aux .h une fois sera suffisant)
$(OBJ)/depandance1.o : include1 inlcude0
$(OBJ)/depandance2.o : include2 include0
```
Les dépendances de nos fichiers.o correspondent aux includes mentionnées dans le fichier
De cette manière les dépandances seront ajoutés lors de la compilation de tous les fichiers .o quelques lignes plus tard par une solution générique.

Cette approche est moins génériques mais permet plus de précision et de clareté sur les dépandances requises pour chaque fichier.
**Attention : vpath ne permet pas de raccourcir les noms des fichiers placés dans obj, on rajoute donc le chemin devant.**

### debuggage

Ces commandes sont présentes pour le confort des developeurs.
Commande `make valgrind` pour utiliser valgrind sur l'executable.
Commande `make debug` pour utiliser le debugger gdb.
(il sera recompilé si besoin)

## Doxygen

### Generer la documentation

La commande `make doc` permet de génerer une documentation du projet.
La documentation web se trouve dans *./bin/html* , ouvrez le fichier *index.html* avec un navigateur afin d'acceder à la documentation

### Ecrire la documentation

Afin que la documentation soit bien générée le fichier , respecter les différentes [normes de commentaires doxygen](https://www.doxygen.nl/manual/docblocks.html)
Chaque fichier, fonction, typedef/structure ou macros peut-être commenté si celà améliore la **lisibilité** du fichier !

### Emplacement de la documentation

La **documentation se fera dans les fichiers en-tête** tandis que les précisions sur le fonctionnement des fonctions peuvent se faire dans les fichiers c, en effet **le code source ne fait pas partie de la documentation générée volontairement**.

## Level

### Schéma d'un fichier level

```txt
longueur_x

hauteur_y

nb_cible

matrice
 de x*y
sur plu
-sieurs 
 lignes 
```

```tx
10

5

2

3 3 3 3 3 3 3 3 3 3 
3 0 0 0 0 0 2 2 0 3
3 0 0 0 1 1 0 0 0 3
3 0 0 7 0 0 0 0 0 3
3 3 3 3 3 3 3 3 3 3
```

### Prérequis sur l'écriture

Le nombre de cible doit être au minimum de 1 et les dimensions de 5*3 ou 3*5 minimum

## Texture

Simple art ascii avec dimension par défaut de 3*5 pour une impression plus carrée sur terminal

```txt
  o  
 /|\ 
 / \ 
```

## Code d'erreurs

### ERREUR 1

Un des fichiers de texture néssaire à l'affichage n'a pas été trouvé.

### ERREUR 2

L'allocation et la création de la map a rencontré une erreur

### ERREUR 3

Mauvaise écriture du niveau choisis : dimension mal bornée

### ERREUR 4

Mauvaise écriture du niveau choisis : nombre de cible et de caisse non-respécté.

#### ERREUR 5

Le fichier selectionné n'existe pas, le NB_LEVEL n'est pas adapté ou fichier manquant.

## Note du prof

- Il est étrange de mettre la documentation dans le dossier bin.
  Ok, je change
- Il n’est pas pertinent de faire une cible dans le makefile pour valgrind, gdb, et run
  Pour le confort des dev c'est à mon avis pertinent. tout comme l'organisation non-générique afin de garder un maximum de control sur le makefile lorsque l'on travaille chacuns de son coté. Lors des dernières versions, le makefile a été modifée afin d'être plus générique, les fichiers gardés étant tous requis.
- La commande "make archive" ne produit pas le résultat attendu. Cette commande doit générer une archive ne contenant que les fichiers nécessaires au projet.
  Elle à l'air de très bien fonctionner (peut-etre que les fichiers de tests sont trop ?)
- Le repo Git contient des fichiers qui ne sont pas nécessaires au projet. Il est important que le repo Git ne contienne que les fichiers nécessaires au projet.
  *Oui
- Le rapport et/ou le readme est/sont manquant(s). Il est important que le rapport et le readme soient présents dans le repo Git.
  Le readme est là depuis Jour 0.
