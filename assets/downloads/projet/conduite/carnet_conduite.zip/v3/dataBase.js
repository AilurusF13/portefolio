const listeMeteo=[{"IDmeteo":1,"NOMmeteo":"vent","SCOREmeteo":1},{"IDmeteo":2,"NOMmeteo":"pluie","SCOREmeteo":1},{"IDmeteo":3,"NOMmeteo":"nuit","SCOREmeteo":1},{"IDmeteo":4,"NOMmeteo":"neige","SCOREmeteo":2},{"IDmeteo":5,"NOMmeteo":"brouillard","SCOREmeteo":2},{"IDmeteo":6,"NOMmeteo":"orage","SCOREmeteo":2}] ;

const listeTrafic=[{"IDtrafic":1,"NOMtrafic":"Modéré"},{"IDtrafic":2,"NOMtrafic":"Dense"},{"IDtrafic":3,"NOMtrafic":"Embouteillage"},{"IDtrafic":4,"NOMtrafic":"Calme"}] ;

const listeManoeuvre=[{"IDmanoeuvre":1,"NOMmanoeuvre":"bataille"},{"IDmanoeuvre":2,"NOMmanoeuvre":"créneau"},{"IDmanoeuvre":3,"NOMmanoeuvre":"marche arrière"},{"IDmanoeuvre":4,"NOMmanoeuvre":"épi"}] ;

const listeRoute=[{"IDroute":1,"NOMroute":"autoroute"},{"IDroute":2,"NOMroute":"centre-ville"},{"IDroute":3,"NOMroute":"campagne"},{"IDroute":4,"NOMroute":"zone industrielle"},{"IDroute":5,"NOMroute":"voie-rapide"},{"IDroute":1,"NOMroute":"zone résidentielle"}] ;

const listeCouleurs=[{"IDcouleur":1,"NOMcouleur":"rouge","CODEcouleur":"#fc9b92"},{"IDcouleur":2,"NOMcouleur":"jaune","CODEcouleur":"#fce492"},{"IDcouleur":3,"NOMcouleur":"bleu","CODEcouleur":"#96faf3"},{"IDcouleur":4,"NOMcouleur":"blanc","CODEcouleur":"#d7f3ff"},{"IDcouleur":5,"NOMcouleur":"rose","CODEcouleur":"#ecb5f5"}];